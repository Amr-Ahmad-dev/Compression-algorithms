"""
Main Entry Point for the File Compression Laboratory.
Supports both Graphical Desktop UI and Headless CLI / Benchmarking / File Generation modes.
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from algorithms import ALGORITHM_REGISTRY, get_algorithm
from algorithms.base import AlgorithmId, AlgorithmConfig
from core.container import build_container, decompress_container
from core.statistics import analyze_bytes, analyze_file
from analysis.benchmark import TournamentRunner, TournamentEntry
from analysis.generator import generate_entropy_file


def run_cli_demo(data_input: bytes = None, dataset_name: str = "sample_benchmark.txt"):
    print("=" * 75)
    print("🔬 ANTIGRAVITY FILE COMPRESSION LABORATORY — TOURNAMENT BENCHMARK")
    print("=" * 75)

    if data_input is None:
        sample_text = (
            "Information theory establishes fundamental limits on data compression and communication. "
            "Claude Shannon proved that the shortest average code length for lossless compression "
            "is bounded below by the Shannon entropy H(X) = -sum p(x) log2 p(x). "
            "Algorithms tested: Huffman, Arithmetic (Static & Adaptive), Shannon-Fano, LZW, RLE! "
        ) * 40
        data = sample_text.encode("utf-8")
    else:
        data = data_input

    print(f"\n[+] Input Target: '{dataset_name}' ({len(data):,} bytes)")
    stats = analyze_bytes(data)
    print(f"[+] Shannon Entropy: {stats.shannon_entropy:.4f} bits/symbol (Max: {stats.max_entropy:.2f})")
    print(f"[+] Theoretical Shannon Bound: {stats.theoretical_min_size_bytes:,.1f} bytes")
    print(f"[+] Conditional Entropy H(X|Y): {stats.conditional_entropy:.4f} bits/symbol")

    competitors = [
        TournamentEntry(AlgorithmId.HUFFMAN, "Huffman (Byte)", AlgorithmConfig(AlgorithmId.HUFFMAN, block_size=1)),
        TournamentEntry(AlgorithmId.HUFFMAN, "Huffman (BS=2)", AlgorithmConfig(AlgorithmId.HUFFMAN, block_size=2)),
        TournamentEntry(AlgorithmId.ARITHMETIC_STATIC, "Arithmetic (Static)", AlgorithmConfig(AlgorithmId.ARITHMETIC_STATIC, block_size=1)),
        TournamentEntry(AlgorithmId.ARITHMETIC_ADAPTIVE, "Arithmetic (Adaptive)", AlgorithmConfig(AlgorithmId.ARITHMETIC_ADAPTIVE, block_size=1)),
        TournamentEntry(AlgorithmId.SHANNON_FANO, "Shannon-Fano", AlgorithmConfig(AlgorithmId.SHANNON_FANO, block_size=1)),
        TournamentEntry(AlgorithmId.LZW, "LZW (Dictionary)", AlgorithmConfig(AlgorithmId.LZW, block_size=1)),
        TournamentEntry(AlgorithmId.RLE, "RLE (PackBits)", AlgorithmConfig(AlgorithmId.RLE, block_size=1)),
        TournamentEntry(AlgorithmId.DELTA_HUFFMAN, "Delta + Huffman", AlgorithmConfig(AlgorithmId.DELTA_HUFFMAN, block_size=1)),
    ]

    runner = TournamentRunner()
    records = runner.run_single_competition(data, dataset_name, competitors)

    print("\n" + "=" * 105)
    print(f"{'Rk':<3} | {'Algorithm':<22} | {'Payload (Ratio)':<18} | {'Total Container':<18} | {'Comp(ms)':<8} | {'Decomp(ms)':<10} | {'Integrity'}")
    print("-" * 105)
    for r in sorted(records, key=lambda x: x.rank_storage):
        integ = "✓ PASS" if r.integrity_verified else "✗ FAIL"
        pay_str = f"{r.payload_size:,} B ({r.payload_ratio:.2f}x)"
        cont_str = f"{r.total_container_size:,} B ({r.storage_ratio:.2f}x)"
        print(
            f"#{r.rank_storage:<2} | {r.algorithm_name:<22} | {pay_str:<18} | {cont_str:<18} | "
            f"{r.compression_time_ms:<8.1f} | {r.decompression_time_ms:<10.1f} | {integ}"
        )
        if r.overhead_eliminates_savings:
            print(f"    ↳ Notice: {r.performance_insight}")
    print("=" * 105)

    best_storage = min(records, key=lambda r: r.total_container_size)
    best_payload = min(records, key=lambda r: r.payload_size)
    print(f"\n🏆 Storage Winner: {best_storage.algorithm_name} (Container: {best_storage.total_container_size:,} B, Ratio: {best_storage.storage_ratio:.2f}x)")
    print(f"🎯 Pure Payload Best: {best_payload.algorithm_name} (Payload: {best_payload.payload_size:,} B, Ratio: {best_payload.payload_ratio:.2f}x)")


def main():
    parser = argparse.ArgumentParser(description="File Compression Laboratory")
    parser.add_argument("--cli", action="store_true", help="Run command-line tournament demo")
    parser.add_argument("--file", type=str, help="Inspect statistical properties of a file")
    parser.add_argument("--benchmark-file", type=str, help="Run compression tournament directly on a specified file")
    parser.add_argument("--generate-file", type=str, help="Generate a binary file with calibrated entropy to specified path")
    parser.add_argument("--size", type=int, default=1048576, help="File size in bytes for generation (default: 1 MB)")
    parser.add_argument("--entropy", type=float, default=0.5, help="Target normalized entropy [0.0..1.0] (default: 0.5)")
    parser.add_argument("--seed", type=int, default=None, help="Random seed for reproducible generation")
    args = parser.parse_args()

    if args.generate_file:
        print(f"Generating file '{args.generate_file}' of size {args.size:,} bytes with target normalized entropy {args.entropy:.2f}...")
        t_bits, m_bits, written = generate_entropy_file(
            filepath=args.generate_file,
            size_bytes=args.size,
            target_normalized_entropy=args.entropy,
            seed=args.seed
        )
        print(f"✓ Success! Written {written:,} bytes.")
        print(f"  Target Entropy: {t_bits:.2f} bits/symbol | Measured Entropy: {m_bits:.4f} bits/symbol")

    elif args.benchmark_file:
        p = Path(args.benchmark_file)
        if not p.exists():
            print(f"Error: file not found: {args.benchmark_file}")
            sys.exit(1)
        with open(p, "rb") as fl:
            data = fl.read()
        run_cli_demo(data, p.name)

    elif args.file:
        p = Path(args.file)
        if not p.exists():
            print(f"Error: file not found: {args.file}")
            sys.exit(1)
        stats = analyze_file(str(p.resolve()))
        print(f"=== Statistical Profile: {stats.source_name} ===")
        print(f"Total Size: {stats.total_bytes:,} Bytes")
        print(f"Unique Symbols: {stats.unique_symbols} / 256")
        print(f"Shannon Entropy H(X): {stats.shannon_entropy:.4f} bits/byte")
        print(f"Max Possible Entropy: {stats.max_entropy:.4f} bits/byte")
        print(f"Theoretical Minimum (Shannon Bound): {stats.theoretical_min_size_bytes:,.1f} Bytes")
        print(f"Conditional Entropy H(X_i | X_{{i-1}}): {stats.conditional_entropy:.4f} bits/byte")
        print(f"Zero Bytes: {stats.zero_byte_count:,} ({stats.zero_byte_ratio*100:.2f}%)")
        print(f"Printable ASCII: {stats.printable_count:,} ({stats.printable_ratio*100:.2f}%)")

    elif args.cli:
        run_cli_demo()

    else:
        try:
            from interface.app import run_app
            run_app()
        except Exception as e:
            print(f"Note: Could not initialize GUI ({e}). Falling back to CLI demo.")
            run_cli_demo()


if __name__ == "__main__":
    main()
