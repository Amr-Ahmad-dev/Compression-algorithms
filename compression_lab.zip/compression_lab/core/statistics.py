"""
Statistical Analysis and Information Theory Engine.
Calculates Shannon entropy, probability distributions, autocorrelation,
conditional entropy, n-grams, and theoretical compression limits.
Includes educational metadata explaining each metric and its practical compression significance.
"""

import math
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import numpy as np


@dataclass
class FileStatistics:
    """Comprehensive statistical and information-theoretic profile of a dataset or file."""
    source_name: str
    source_path: str
    total_bytes: int
    unique_symbols: int
    shannon_entropy: float              # Empirical measured zero-order entropy H(X)
    max_entropy: float                  # Theoretical maximum entropy for the alphabet
    theoretical_min_size_bytes: float   # Shannon lower bound: (N * H) / 8
    zero_byte_count: int
    zero_byte_ratio: float
    printable_count: int
    printable_ratio: float
    ascii_count: int
    ascii_ratio: float
    byte_frequencies: Dict[int, int]
    byte_probabilities: Dict[int, float]
    top_symbols: List[Tuple[int, int, float]]   # (byte_val, count, prob)
    bottom_symbols: List[Tuple[int, int, float]]
    conditional_entropy: float = 0.0            # H(X_i | X_{i-1})
    autocorrelation: List[float] = field(default_factory=list) # Lags 1..32
    top_bigrams: List[Tuple[Tuple[int, int], int, float]] = field(default_factory=list)
    chunk_entropies: List[float] = field(default_factory=list)


# Educational descriptions for every displayed metric
METRIC_EXPLANATIONS = {
    "shannon_entropy": {
        "title": "Shannon Entropy H(X)",
        "kind": "Measured Property",
        "description": "Measures the average uncertainty or information density per byte in bits.",
        "significance": "Under Claude Shannon's Source Coding Theorem, this represents the theoretical lowest average bits per symbol achievable by any lossless zero-order code."
    },
    "max_entropy": {
        "title": "Maximum Possible Entropy",
        "kind": "Theoretical Upper Bound",
        "description": "log2(alphabet_size) = 8.000 bits/byte for a 256-symbol byte alphabet.",
        "significance": "Achieved only when every byte value from 0 to 255 appears with equal probability (uniform randomness). A file with H ≈ 8.0 is mathematically incompressible."
    },
    "theoretical_min_size": {
        "title": "Shannon Minimum Bound",
        "kind": "Theoretical Lower Limit",
        "description": "(File Size * H(X)) / 8 bytes.",
        "significance": "The absolute minimum file size possible if every symbol were encoded at its true theoretical entropy. Real compressed files will be larger due to metadata and header overhead."
    },
    "conditional_entropy": {
        "title": "Conditional Entropy H(X_i | X_{i-1})",
        "kind": "Measured 1st-Order Property",
        "description": "Measures remaining uncertainty about a byte when the immediately preceding byte is known.",
        "significance": "When conditional entropy is significantly lower than zero-order entropy, the file possesses strong sequential patterns that dictionary compressors (LZW) or Delta differencing can compress well."
    },
    "autocorrelation": {
        "title": "Byte Autocorrelation ρ(k)",
        "kind": "Measured Structural Property",
        "description": "Correlation between byte values separated by a distance (lag) of k bytes.",
        "significance": "Spikes at specific lags indicate periodic structures (e.g., fixed-width database records or repeating raster lines)."
    },
    "zero_byte_ratio": {
        "title": "Zero-Byte Ratio (0x00)",
        "kind": "Measured Distribution Property",
        "description": "Percentage of total bytes that are null bytes (0x00).",
        "significance": "High zero-byte concentrations are common in uncompressed binaries, sparse data, and padded structures, making them prime targets for Run-Length Encoding (RLE)."
    },
    "printable_ratio": {
        "title": "Printable ASCII Ratio",
        "kind": "Measured Distribution Property",
        "description": "Percentage of bytes corresponding to human-readable characters (ASCII 32..126, tabs, newlines).",
        "significance": "Indicates whether the input is plain text or binary. Text typically uses only 60-90 distinct symbols, reducing entropy significantly."
    }
}


def calculate_entropy(frequencies: Dict[int, int], total_count: int) -> float:
    """Calculate Shannon entropy H(X) = -sum(p * log2(p))."""
    if total_count <= 0:
        return 0.0
    entropy = 0.0
    for count in frequencies.values():
        if count > 0:
            p = count / total_count
            entropy -= p * math.log2(p)
    return entropy


def analyze_bytes(
    data: bytes,
    source_name: str = "in_memory_buffer",
    source_path: str = ""
) -> FileStatistics:
    """
    Analyzes byte data in memory and computes both fundamental and advanced statistical properties.
    """
    total_bytes = len(data)
    if total_bytes == 0:
        return FileStatistics(
            source_name=source_name,
            source_path=source_path,
            total_bytes=0,
            unique_symbols=0,
            shannon_entropy=0.0,
            max_entropy=8.0,
            theoretical_min_size_bytes=0.0,
            zero_byte_count=0,
            zero_byte_ratio=0.0,
            printable_count=0,
            printable_ratio=0.0,
            ascii_count=0,
            ascii_ratio=0.0,
            byte_frequencies={i: 0 for i in range(256)},
            byte_probabilities={i: 0.0 for i in range(256)},
            top_symbols=[],
            bottom_symbols=[],
            conditional_entropy=0.0,
            autocorrelation=[0.0] * 32,
            top_bigrams=[],
            chunk_entropies=[]
        )

    # 1. Byte frequencies
    counts_array = np.bincount(np.frombuffer(data, dtype=np.uint8), minlength=256)
    byte_frequencies = {i: int(counts_array[i]) for i in range(256)}
    byte_probabilities = {i: float(counts_array[i] / total_bytes) for i in range(256)}
    unique_symbols = int(np.count_nonzero(counts_array))

    # 2. Shannon Entropy & Bounds
    entropy = calculate_entropy(byte_frequencies, total_bytes)
    max_entropy = 8.0
    theoretical_min = (total_bytes * entropy) / 8.0

    # 3. Categorical properties
    zero_bytes = byte_frequencies[0]
    printable_set = set(range(32, 127)) | {9, 10, 13}
    printable_count = sum(byte_frequencies[b] for b in printable_set)
    ascii_count = sum(byte_frequencies[b] for b in range(128))

    # 4. Top and bottom symbols
    sorted_symbols = sorted(
        [(b, count, count / total_bytes) for b, count in byte_frequencies.items() if count > 0],
        key=lambda x: x[1],
        reverse=True
    )
    top_symbols = sorted_symbols[:10]
    bottom_symbols = sorted_symbols[-10:] if len(sorted_symbols) > 10 else list(reversed(sorted_symbols))

    # 5. Advanced statistics: Bigrams, Conditional Entropy, Autocorrelation, Local chunk entropy
    cond_entropy = 0.0
    autocorr = [0.0] * 32
    top_bigrams: List[Tuple[Tuple[int, int], int, float]] = []
    chunk_entropies: List[float] = []

    if total_bytes > 1:
        # Sample for autocorrelation and bigrams if data is huge (> 1 MB) to remain fast
        if total_bytes > 1048576:
            sample_data = data[:1048576]
        else:
            sample_data = data

        sample_len = len(sample_data)
        bigram_counts = Counter()
        for i in range(sample_len - 1):
            bigram_counts[(sample_data[i], sample_data[i + 1])] += 1

        total_bigrams = sample_len - 1
        joint_entropy = 0.0
        for count in bigram_counts.values():
            p_xy = count / total_bigrams
            joint_entropy -= p_xy * math.log2(p_xy)

        cond_entropy = max(0.0, joint_entropy - entropy)

        sorted_bigrams = sorted(bigram_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        top_bigrams = [(bg, cnt, cnt / total_bigrams) for bg, cnt in sorted_bigrams]

        # Autocorrelation (lags 1..32)
        arr = np.frombuffer(sample_data, dtype=np.uint8).astype(np.float64)
        mean_val = np.mean(arr)
        variance = np.var(arr)
        if variance > 1e-9:
            max_lag = min(32, sample_len - 1)
            for k in range(1, max_lag + 1):
                cov = np.mean((arr[:-k] - mean_val) * (arr[k:] - mean_val))
                autocorr[k - 1] = float(cov / variance)

        # Local chunk entropy profile (50 slices across the file)
        num_chunks = min(50, total_bytes // 64) if total_bytes >= 64 else 1
        chunk_size = total_bytes // num_chunks
        for i in range(num_chunks):
            start = i * chunk_size
            end = (i + 1) * chunk_size if i < num_chunks - 1 else total_bytes
            chunk_slice = data[start:end]
            chunk_counts = Counter(chunk_slice)
            chunk_entropies.append(calculate_entropy(chunk_counts, len(chunk_slice)))
    else:
        chunk_entropies.append(entropy)

    return FileStatistics(
        source_name=source_name,
        source_path=source_path,
        total_bytes=total_bytes,
        unique_symbols=unique_symbols,
        shannon_entropy=round(entropy, 4),
        max_entropy=max_entropy,
        theoretical_min_size_bytes=round(theoretical_min, 1),
        zero_byte_count=zero_bytes,
        zero_byte_ratio=round(zero_bytes / total_bytes, 4),
        printable_count=printable_count,
        printable_ratio=round(printable_count / total_bytes, 4),
        ascii_count=ascii_count,
        ascii_ratio=round(ascii_count / total_bytes, 4),
        byte_frequencies=byte_frequencies,
        byte_probabilities=byte_probabilities,
        top_symbols=top_symbols,
        bottom_symbols=bottom_symbols,
        conditional_entropy=round(cond_entropy, 4),
        autocorrelation=autocorr,
        top_bigrams=top_bigrams,
        chunk_entropies=chunk_entropies
    )


def analyze_file(filepath: str, max_sample_bytes: int = 1048576) -> FileStatistics:
    """
    Streaming analyzer for files of any size (from bytes to 100+ MB).
    Reads chunks to compute global frequencies, and samples up to 1 MB for autocorrelation.
    """
    path_obj = Path(filepath)
    if not path_obj.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    file_size = path_obj.stat().st_size
    if file_size == 0:
        return analyze_bytes(b"", source_name=path_obj.name, source_path=str(path_obj.resolve()))

    # If small enough, analyze directly in memory
    if file_size <= max_sample_bytes:
        with open(path_obj, "rb") as f:
            data = f.read()
        return analyze_bytes(data, source_name=path_obj.name, source_path=str(path_obj.resolve()))

    # Large file streaming
    counts_array = np.zeros(256, dtype=np.int64)
    total_bytes = 0
    zero_bytes = 0
    printable_set = set(range(32, 127)) | {9, 10, 13}
    printable_count = 0
    ascii_count = 0

    sample_buffer = bytearray()
    chunk_size = 65536

    with open(path_obj, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            chunk_len = len(chunk)
            total_bytes += chunk_len
            arr = np.frombuffer(chunk, dtype=np.uint8)
            counts_array += np.bincount(arr, minlength=256)

            # Accumulate sample for autocorrelation & conditional entropy
            if len(sample_buffer) < max_sample_bytes:
                needed = max_sample_bytes - len(sample_buffer)
                sample_buffer.extend(chunk[:needed])

    byte_frequencies = {i: int(counts_array[i]) for i in range(256)}
    byte_probabilities = {i: float(counts_array[i] / total_bytes) for i in range(256)}
    unique_symbols = int(np.count_nonzero(counts_array))

    zero_bytes = byte_frequencies[0]
    printable_count = sum(byte_frequencies[b] for b in printable_set)
    ascii_count = sum(byte_frequencies[b] for b in range(128))

    entropy = calculate_entropy(byte_frequencies, total_bytes)
    theoretical_min = (total_bytes * entropy) / 8.0

    sorted_symbols = sorted(
        [(b, count, count / total_bytes) for b, count in byte_frequencies.items() if count > 0],
        key=lambda x: x[1],
        reverse=True
    )
    top_symbols = sorted_symbols[:10]
    bottom_symbols = sorted_symbols[-10:] if len(sorted_symbols) > 10 else list(reversed(sorted_symbols))

    # Compute advanced properties on sample buffer
    cond_entropy = 0.0
    autocorr = [0.0] * 32
    top_bigrams: List[Tuple[Tuple[int, int], int, float]] = []

    if len(sample_buffer) > 1:
        sample_len = len(sample_buffer)
        bigram_counts = Counter()
        for i in range(sample_len - 1):
            bigram_counts[(sample_buffer[i], sample_buffer[i + 1])] += 1

        total_bigrams = sample_len - 1
        joint_entropy = 0.0
        for count in bigram_counts.values():
            p_xy = count / total_bigrams
            joint_entropy -= p_xy * math.log2(p_xy)

        cond_entropy = max(0.0, joint_entropy - entropy)
        sorted_bigrams = sorted(bigram_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        top_bigrams = [(bg, cnt, cnt / total_bigrams) for bg, cnt in sorted_bigrams]

        arr = np.frombuffer(sample_buffer, dtype=np.uint8).astype(np.float64)
        mean_val = np.mean(arr)
        variance = np.var(arr)
        if variance > 1e-9:
            for k in range(1, 33):
                cov = np.mean((arr[:-k] - mean_val) * (arr[k:] - mean_val))
                autocorr[k - 1] = float(cov / variance)

    # Chunk entropies sampled across file
    chunk_entropies = [entropy]

    return FileStatistics(
        source_name=path_obj.name,
        source_path=str(path_obj.resolve()),
        total_bytes=total_bytes,
        unique_symbols=unique_symbols,
        shannon_entropy=round(entropy, 4),
        max_entropy=8.0,
        theoretical_min_size_bytes=round(theoretical_min, 1),
        zero_byte_count=zero_bytes,
        zero_byte_ratio=round(zero_bytes / total_bytes, 4),
        printable_count=printable_count,
        printable_ratio=round(printable_count / total_bytes, 4),
        ascii_count=ascii_count,
        ascii_ratio=round(ascii_count / total_bytes, 4),
        byte_frequencies=byte_frequencies,
        byte_probabilities=byte_probabilities,
        top_symbols=top_symbols,
        bottom_symbols=bottom_symbols,
        conditional_entropy=round(cond_entropy, 4),
        autocorrelation=autocorr,
        top_bigrams=top_bigrams,
        chunk_entropies=chunk_entropies
    )
