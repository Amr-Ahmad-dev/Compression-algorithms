"""
Statistical Analysis View for the Compression Laboratory GUI.
Visualizes Shannon entropy, byte histograms, autocorrelation, conditional entropy,
and theoretical limits with educational explanations of each metric's compression significance.
"""

from typing import Dict, Any, List
import customtkinter as ctk
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from pathlib import Path
from core.statistics import FileStatistics, analyze_bytes, analyze_file, METRIC_EXPLANATIONS
from visualization.charts import (
    create_histogram_figure,
    create_local_entropy_figure,
    create_autocorrelation_figure
)


class AnalysisView(ctk.CTkFrame):
    def __init__(self, master, get_shared_state, set_shared_state, **kwargs):
        super().__init__(master, **kwargs)
        self.get_shared_state = get_shared_state
        self.set_shared_state = set_shared_state
        self.canvas = None
        self.current_fig = None

        self._build_ui()

    def _build_ui(self):
        self.grid_columnconfigure((0, 1, 2, 3), weight=1)
        self.grid_rowconfigure(3, weight=1)

        # 1. Target File Indicator Banner (Requirement 5)
        self.banner = ctk.CTkFrame(self, corner_radius=8, fg_color=("#E2E8F0", "#1E293B"))
        self.banner.grid(row=0, column=0, columnspan=4, padx=15, pady=(10, 5), sticky="ew")
        self.banner.grid_columnconfigure(0, weight=1)

        self.lbl_target = ctk.CTkLabel(
            self.banner,
            text="Currently Analyzing: None",
            font=ctk.CTkFont(size=13, weight="bold"),
            anchor="w"
        )
        self.lbl_target.grid(row=0, column=0, padx=15, pady=6, sticky="w")

        # 2. Metric Cards (Row 1)
        self.card_entropy = self._create_metric_card(
            "Measured: Shannon Entropy H(X)", "0.0000", "bits / byte", 0, "shannon_entropy"
        )
        self.card_max_entropy = self._create_metric_card(
            "Theoretical: Max H(X)", "8.0000", "bits (uniform)", 1, "max_entropy"
        )
        self.card_theo_bound = self._create_metric_card(
            "Theoretical: Minimum Size", "0 B", "Shannon bound", 2, "theoretical_min_size"
        )
        self.card_cond_entropy = self._create_metric_card(
            "Measured: Conditional H(X|Y)", "0.0000", "1st order memory", 3, "conditional_entropy"
        )

        # 3. Controls & Chart Selection Bar (Row 2)
        ctrl_bar = ctk.CTkFrame(self, fg_color="transparent")
        ctrl_bar.grid(row=2, column=0, columnspan=4, padx=15, pady=(6, 4), sticky="ew")

        ctk.CTkButton(
            ctrl_bar,
            text="Refresh Analysis",
            width=130,
            command=self.refresh_analysis
        ).pack(side="left", padx=5)

        self.chart_selector = ctk.CTkSegmentedButton(
            ctrl_bar,
            values=["Byte Histogram", "Local Chunk Entropy", "Autocorrelation"],
            command=self._on_chart_changed
        )
        self.chart_selector.set("Byte Histogram")
        self.chart_selector.pack(side="right", padx=5)

        # 4. Chart Container (Row 3, Left)
        self.chart_frame = ctk.CTkFrame(self, corner_radius=10)
        self.chart_frame.grid(row=3, column=0, columnspan=3, padx=(15, 5), pady=8, sticky="nsew")

        # 5. Side Panel: Educational Insight & Top Symbols (Row 3, Right)
        side_panel = ctk.CTkFrame(self, corner_radius=10)
        side_panel.grid(row=3, column=3, padx=(5, 15), pady=8, sticky="nsew")

        ctk.CTkLabel(side_panel, text="Top Symbols & Bigrams", font=ctk.CTkFont(size=12, weight="bold")).pack(
            anchor="w", padx=10, pady=(8, 2)
        )
        self.table_box = ctk.CTkTextbox(side_panel, font=ctk.CTkFont(family="Consolas", size=10), height=170)
        self.table_box.pack(fill="x", padx=10, pady=2)

        ctk.CTkLabel(side_panel, text="Educational Metric Guide", font=ctk.CTkFont(size=12, weight="bold")).pack(
            anchor="w", padx=10, pady=(10, 2)
        )
        self.guide_box = ctk.CTkTextbox(side_panel, font=ctk.CTkFont(size=11), wrap="word", height=190)
        self.guide_box.pack(fill="both", expand=True, padx=10, pady=(2, 10))

        self._populate_guide()

    def _create_metric_card(self, title: str, value: str, sub: str, col: int, metric_key: str) -> Dict[str, Any]:
        frame = ctk.CTkFrame(self, corner_radius=8)
        frame.grid(row=1, column=col, padx=6, pady=4, sticky="ew")
        lbl_title = ctk.CTkLabel(frame, text=title, font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8")
        lbl_title.pack(anchor="w", padx=10, pady=(6, 0))
        lbl_val = ctk.CTkLabel(frame, text=value, font=ctk.CTkFont(size=17, weight="bold"))
        lbl_val.pack(anchor="w", padx=10, pady=0)
        lbl_sub = ctk.CTkLabel(frame, text=sub, font=ctk.CTkFont(size=10), text_color="gray")
        lbl_sub.pack(anchor="w", padx=10, pady=(0, 6))
        return {"val": lbl_val, "sub": lbl_sub}

    def _populate_guide(self):
        text = (
            "• Shannon Entropy H(X): Measured bits of information per byte. Lower entropy means higher potential compression.\n\n"
            "• Theoretical Min: Lowest possible bytes achievable without loss under zero-order models.\n\n"
            "• Conditional Entropy: Predictability given previous byte. If much lower than H(X), LZW and Delta will perform strongly.\n\n"
            "• Autocorrelation: Detects repeating cycles and periodicity across byte lags."
        )
        self.guide_box.delete("1.0", "end")
        self.guide_box.insert("1.0", text)

    def refresh_analysis(self):
        data = self.get_shared_state("active_data")
        name = self.get_shared_state("active_name") or "Unnamed Sample"
        path = self.get_shared_state("active_path") or ""

        if data is None or len(data) == 0:
            # Fallback
            data = "Compression Laboratory Sample: The quick brown fox jumps over the lazy dog. 1234567890".encode("utf-8")
            self.set_shared_state("active_data", data)
            self.set_shared_state("active_name", "sample.txt")
            name = "sample.txt"

        # Check if actual path exists for streaming
        if path and Path(path).exists():
            stats = analyze_file(path)
        else:
            stats = analyze_bytes(data, source_name=name, source_path=path)

        self.set_shared_state("active_stats", stats)

        # Update banner
        size_str = f"{len(data):,} Bytes ({len(data)/1024:.1f} KB)"
        self.lbl_target.configure(text=f"Currently Analyzing: {name} | Size: {size_str}")

        # Update cards
        self.card_entropy["val"].configure(text=f"{stats.shannon_entropy:.4f}")
        self.card_max_entropy["val"].configure(text=f"{stats.max_entropy:.4f}")
        self.card_theo_bound["val"].configure(text=f"{stats.theoretical_min_size_bytes:,.0f} B")
        self.card_cond_entropy["val"].configure(text=f"{stats.conditional_entropy:.4f}")

        # Update table box
        lines = [f"{'Byte':<8} | {'Count':<8} | {'Prob':<8}", "-" * 28]
        for b, count, prob in stats.top_symbols:
            char_rep = f"'{chr(b)}'" if 32 <= b <= 126 else f"0x{b:02X}"
            lines.append(f"{char_rep:<8} | {count:<8} | {prob:.4f}")

        if stats.top_bigrams:
            lines.append("\nTop Bigrams (X, Y):")
            lines.append(f"{'Bigram':<10} | {'Count':<6} | {'Prob':<6}")
            lines.append("-" * 28)
            for (b1, b2), count, prob in stats.top_bigrams[:5]:
                bg_str = f"{chr(b1) if 32 <= b1 <= 126 else '?'}{chr(b2) if 32 <= b2 <= 126 else '?'}"
                lines.append(f"{bg_str:<10} | {count:<6} | {prob:.4f}")

        self.table_box.delete("1.0", "end")
        self.table_box.insert("1.0", "\n".join(lines))

        self._render_current_chart(stats)

    def _on_chart_changed(self, value):
        stats = self.get_shared_state("active_stats")
        if stats:
            self._render_current_chart(stats)

    def _render_current_chart(self, stats: FileStatistics):
        selected = self.chart_selector.get()
        if self.current_fig:
            plt.close(self.current_fig)
        if self.canvas:
            self.canvas.get_tk_widget().destroy()

        if selected == "Byte Histogram":
            fig = create_histogram_figure(stats.byte_frequencies, dark_mode=True)
        elif selected == "Local Chunk Entropy":
            fig = create_local_entropy_figure(stats.chunk_entropies, stats.shannon_entropy, dark_mode=True)
        else:
            fig = create_autocorrelation_figure(stats.autocorrelation, dark_mode=True)

        self.current_fig = fig
        self.canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)
