"""
Dashboard View for the Compression Laboratory GUI.
Provides quick file/folder selection, detailed dual-metric size reporting
(Payload vs Storage Compression), and rapid compression/decompression actions.
"""

import os
import time
from pathlib import Path
from tkinter import filedialog, messagebox
import customtkinter as ctk

from algorithms import get_algorithm
from algorithms.base import AlgorithmId, AlgorithmConfig
from core.container import (
    build_container,
    decompress_container,
    pack_directory,
    unpack_directory,
    get_breakdown_from_result
)
from core.statistics import analyze_bytes, analyze_file


def format_size(bytes_val: int) -> str:
    """Formats byte counts into human-readable strings."""
    if bytes_val < 1024:
        return f"{bytes_val:,} B"
    elif bytes_val < 1024 * 1024:
        return f"{bytes_val / 1024:,.2f} KB ({bytes_val:,} B)"
    else:
        return f"{bytes_val / (1024 * 1024):,.2f} MB ({bytes_val:,} B)"


class DashboardView(ctk.CTkFrame):
    def __init__(self, master, get_shared_state, set_shared_state, log_callback, **kwargs):
        super().__init__(master, **kwargs)
        self.get_shared_state = get_shared_state
        self.set_shared_state = set_shared_state
        self.log_callback = log_callback

        self._build_ui()

    def _build_ui(self):
        self.grid_columnconfigure((0, 1), weight=1)

        # 1. Source Selection Card
        sel_card = ctk.CTkFrame(self, corner_radius=10)
        sel_card.grid(row=0, column=0, columnspan=2, padx=15, pady=8, sticky="ew")
        sel_card.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(sel_card, text="Target File or Folder Selection", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, columnspan=3, padx=15, pady=(10, 5), sticky="w"
        )

        self.path_entry = ctk.CTkEntry(sel_card, placeholder_text="Choose an existing file, folder, or generated file...")
        self.path_entry.grid(row=1, column=0, columnspan=2, padx=15, pady=8, sticky="ew")

        btn_box = ctk.CTkFrame(sel_card, fg_color="transparent")
        btn_box.grid(row=1, column=2, padx=15, pady=8, sticky="e")

        ctk.CTkButton(btn_box, text="Browse File", width=100, command=self._browse_file).pack(side="left", padx=5)
        ctk.CTkButton(btn_box, text="Browse Folder", width=110, command=self._browse_folder).pack(side="left", padx=5)

        # 2. Source Properties Card
        self.info_card = ctk.CTkFrame(self, corner_radius=10)
        self.info_card.grid(row=1, column=0, padx=15, pady=8, sticky="nsew")

        ctk.CTkLabel(self.info_card, text="Active Source Properties", font=ctk.CTkFont(size=14, weight="bold")).pack(
            anchor="w", padx=15, pady=(10, 5)
        )
        self.lbl_info_name = ctk.CTkLabel(self.info_card, text="Name: None", anchor="w", font=ctk.CTkFont(weight="bold"))
        self.lbl_info_name.pack(anchor="w", padx=15, pady=2)
        self.lbl_info_size = ctk.CTkLabel(self.info_card, text="Original Size: 0 Bytes", anchor="w")
        self.lbl_info_size.pack(anchor="w", padx=15, pady=2)
        self.lbl_info_entropy = ctk.CTkLabel(self.info_card, text="Shannon Entropy H(X): N/A", anchor="w")
        self.lbl_info_entropy.pack(anchor="w", padx=15, pady=2)
        self.lbl_info_bound = ctk.CTkLabel(self.info_card, text="Theoretical Min (Shannon Bound): N/A", anchor="w")
        self.lbl_info_bound.pack(anchor="w", padx=15, pady=2)

        # 3. Quick Actions Card
        act_card = ctk.CTkFrame(self, corner_radius=10)
        act_card.grid(row=1, column=1, padx=15, pady=8, sticky="nsew")

        ctk.CTkLabel(act_card, text="Compression & Decompression", font=ctk.CTkFont(size=14, weight="bold")).pack(
            anchor="w", padx=15, pady=(10, 5)
        )

        algo_frame = ctk.CTkFrame(act_card, fg_color="transparent")
        algo_frame.pack(fill="x", padx=15, pady=4)
        ctk.CTkLabel(algo_frame, text="Algorithm:").pack(side="left", padx=(0, 10))
        self.algo_dropdown = ctk.CTkComboBox(
            algo_frame,
            values=[
                "Huffman",
                "Arithmetic (Static)",
                "Arithmetic (Adaptive)",
                "Shannon-Fano",
                "LZW",
                "RLE",
                "Delta + Huffman"
            ],
            width=200
        )
        self.algo_dropdown.set("Huffman")
        self.algo_dropdown.pack(side="left")

        bs_frame = ctk.CTkFrame(act_card, fg_color="transparent")
        bs_frame.pack(fill="x", padx=15, pady=4)
        ctk.CTkLabel(bs_frame, text="Block Size:").pack(side="left", padx=(0, 10))
        self.block_size_opt = ctk.CTkSegmentedButton(bs_frame, values=["1 Byte", "2 Bytes", "3 Bytes", "4 Bytes"])
        self.block_size_opt.set("1 Byte")
        self.block_size_opt.pack(side="left")

        btn_row = ctk.CTkFrame(act_card, fg_color="transparent")
        btn_row.pack(fill="x", padx=15, pady=10)
        ctk.CTkButton(
            btn_row,
            text="Compress to .clab",
            fg_color="#3A86FF",
            hover_color="#2563EB",
            font=ctk.CTkFont(weight="bold"),
            command=self._do_compress
        ).pack(side="left", fill="x", expand=True, padx=(0, 5))
        ctk.CTkButton(
            btn_row,
            text="Decompress .clab",
            fg_color="#10B981",
            hover_color="#059669",
            font=ctk.CTkFont(weight="bold"),
            command=self._do_decompress
        ).pack(side="left", fill="x", expand=True, padx=(5, 0))

        # 4. Detailed Sizing Breakdown Card (New Requirement 6)
        self.size_card = ctk.CTkFrame(self, corner_radius=10, fg_color=("#F1F5F9", "#1E293B"))
        self.size_card.grid(row=2, column=0, columnspan=2, padx=15, pady=8, sticky="ew")
        self.size_card.grid_columnconfigure((0, 1, 2, 3), weight=1)

        ctk.CTkLabel(
            self.size_card,
            text="Compression Size Accounting: Payload Efficiency vs Actual Storage",
            font=ctk.CTkFont(size=13, weight="bold")
        ).grid(row=0, column=0, columnspan=4, padx=15, pady=(8, 4), sticky="w")

        self.lbl_payload_metric = ctk.CTkLabel(
            self.size_card,
            text="1. Payload Compression\nPayload Size: 0 B\nRatio: 0.00x (0.0% saved)",
            justify="left",
            font=ctk.CTkFont(size=11)
        )
        self.lbl_payload_metric.grid(row=1, column=0, columnspan=2, padx=15, pady=6, sticky="w")

        self.lbl_storage_metric = ctk.CTkLabel(
            self.size_card,
            text="2. Actual Storage Compression\nTotal Container: 0 B\nRatio: 0.00x (0.0% saved)",
            justify="left",
            font=ctk.CTkFont(size=11)
        )
        self.lbl_storage_metric.grid(row=1, column=2, columnspan=2, padx=15, pady=6, sticky="w")

        self.lbl_overhead_alert = ctk.CTkLabel(
            self.size_card,
            text="Container Breakdown: Ready for compression.",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#94A3B8"
        )
        self.lbl_overhead_alert.grid(row=2, column=0, columnspan=4, padx=15, pady=(2, 8), sticky="w")

        # 5. Activity Log Card
        log_card = ctk.CTkFrame(self, corner_radius=10)
        log_card.grid(row=3, column=0, columnspan=2, padx=15, pady=(8, 12), sticky="nsew")
        self.grid_rowconfigure(3, weight=1)

        ctk.CTkLabel(log_card, text="Activity & Audit Log", font=ctk.CTkFont(size=13, weight="bold")).pack(
            anchor="w", padx=15, pady=(6, 2)
        )
        self.log_text = ctk.CTkTextbox(log_card, height=120, font=ctk.CTkFont(family="Consolas", size=10))
        self.log_text.pack(fill="both", expand=True, padx=15, pady=(0, 10))

    def _browse_file(self):
        f = filedialog.askopenfilename(title="Select File to Analyze or Compress")
        if f:
            self.load_file(f)

    def _browse_folder(self):
        d = filedialog.askdirectory(title="Select Folder to Archive & Compress")
        if d:
            self.load_folder(d)

    def load_file(self, filepath: str):
        p = Path(filepath)
        if not p.exists():
            messagebox.showerror("Error", f"File does not exist: {filepath}")
            return

        self.path_entry.delete(0, "end")
        self.path_entry.insert(0, str(p.resolve()))

        # Read bytes
        with open(p, "rb") as fl:
            raw_bytes = fl.read()

        stats = analyze_file(str(p.resolve()))

        self.lbl_info_name.configure(text=f"Name: {p.name}")
        self.lbl_info_size.configure(text=f"Original Size: {format_size(len(raw_bytes))}")
        self.lbl_info_entropy.configure(text=f"Shannon Entropy H(X): {stats.shannon_entropy:.4f} bits/symbol")
        self.lbl_info_bound.configure(text=f"Theoretical Min (Shannon Bound): {format_size(int(stats.theoretical_min_size_bytes))}")

        self.set_shared_state("active_data", raw_bytes)
        self.set_shared_state("active_name", p.name)
        self.set_shared_state("active_path", str(p.resolve()))
        self.set_shared_state("is_archive", False)
        self.set_shared_state("active_stats", stats)

        self.log(f"Loaded file '{p.name}' ({format_size(len(raw_bytes))}, H={stats.shannon_entropy:.4f} bits/symbol).")

    def load_folder(self, folder_path: str):
        p = Path(folder_path)
        if not p.is_dir():
            messagebox.showerror("Error", f"Directory does not exist: {folder_path}")
            return

        self.path_entry.delete(0, "end")
        self.path_entry.insert(0, str(p.resolve()))

        raw_bytes = pack_directory(p)
        stats = analyze_bytes(raw_bytes, source_name=f"{p.name}_archive", source_path=str(p.resolve()))

        self.lbl_info_name.configure(text=f"Name: [Archive] {p.name}")
        self.lbl_info_size.configure(text=f"Packed Archive Size: {format_size(len(raw_bytes))}")
        self.lbl_info_entropy.configure(text=f"Shannon Entropy H(X): {stats.shannon_entropy:.4f} bits/symbol")
        self.lbl_info_bound.configure(text=f"Theoretical Min (Shannon Bound): {format_size(int(stats.theoretical_min_size_bytes))}")

        self.set_shared_state("active_data", raw_bytes)
        self.set_shared_state("active_name", p.name)
        self.set_shared_state("active_path", str(p.resolve()))
        self.set_shared_state("is_archive", True)
        self.set_shared_state("active_stats", stats)

        self.log(f"Packed directory archive '{p.name}' ({format_size(len(raw_bytes))}).")

    def _get_selected_algorithm_id(self) -> AlgorithmId:
        val = self.algo_dropdown.get()
        mapping = {
            "Huffman": AlgorithmId.HUFFMAN,
            "Arithmetic (Static)": AlgorithmId.ARITHMETIC_STATIC,
            "Arithmetic (Adaptive)": AlgorithmId.ARITHMETIC_ADAPTIVE,
            "Shannon-Fano": AlgorithmId.SHANNON_FANO,
            "LZW": AlgorithmId.LZW,
            "RLE": AlgorithmId.RLE,
            "Delta + Huffman": AlgorithmId.DELTA_HUFFMAN
        }
        return mapping.get(val, AlgorithmId.HUFFMAN)

    def _get_block_size(self) -> int:
        val = self.block_size_opt.get()
        return int(val.split()[0])

    def _do_compress(self):
        data = self.get_shared_state("active_data")
        name = self.get_shared_state("active_name") or "dataset.bin"
        is_archive = self.get_shared_state("is_archive") or False

        if data is None or len(data) == 0:
            messagebox.showwarning("Warning", "Please select a non-empty file or folder first.")
            return

        algo_id = self._get_selected_algorithm_id()
        block_size = self._get_block_size()
        algo = get_algorithm(algo_id)
        cfg = AlgorithmConfig(algorithm_id=algo_id, block_size=block_size)

        self.log(f"Compressing '{name}' using {algo.name} (block_size={block_size})...")
        t0 = time.perf_counter()
        comp_res = algo.compress(data, cfg)
        t_comp = (time.perf_counter() - t0) * 1000.0

        clab_bytes = build_container(comp_res, data, name, is_archive=is_archive)
        breakdown = get_breakdown_from_result(comp_res, name)

        # Update detailed size reporting cards (Requirement 6)
        self.lbl_payload_metric.configure(
            text=(
                f"1. Payload Compression (Algorithm Core)\n"
                f"Payload: {format_size(breakdown.payload_size)} (from {format_size(breakdown.original_size)})\n"
                f"Ratio: {breakdown.payload_ratio:.3f}x | Space Saved: {breakdown.payload_savings_pct:+.2f}%"
            )
        )
        self.lbl_storage_metric.configure(
            text=(
                f"2. Actual Storage Compression (Real Container)\n"
                f"Container: {format_size(breakdown.total_container_size)} (Overhead: {format_size(breakdown.total_overhead_size)})\n"
                f"Ratio: {breakdown.storage_ratio:.3f}x | Space Saved: {breakdown.storage_savings_pct:+.2f}%"
            )
        )

        if breakdown.overhead_eliminates_savings:
            self.lbl_overhead_alert.configure(
                text=f"⚠️ OVERHEAD NOTICE: The algorithm compressed payload by {breakdown.payload_savings_pct:+.1f}%, but metadata overhead ({breakdown.total_overhead_size} B) resulted in a net file expansion of {abs(breakdown.storage_savings_pct):.1f}%!",
                text_color="#EF4444"
            )
        elif breakdown.storage_savings_pct > 0:
            self.lbl_overhead_alert.configure(
                text=f"✓ POSITIVE COMPRESSION: Real storage reduced by {breakdown.storage_savings_pct:.1f}%. Overhead accounts for {breakdown.overhead_pct_of_container:.1f}% of container.",
                text_color="#10B981"
            )
        else:
            self.lbl_overhead_alert.configure(
                text="ℹ Data expanded both in payload and container on this data.",
                text_color="#94A3B8"
            )

        # Prompt save
        out_path = filedialog.asksaveasfilename(
            title="Save Compressed Container",
            initialfile=f"{name}.clab",
            filetypes=[("Compression Laboratory Container", "*.clab")]
        )
        if out_path:
            with open(out_path, "wb") as fl:
                fl.write(clab_bytes)

            self.log(
                f"Saved container '{Path(out_path).name}' ({format_size(len(clab_bytes))}) in {t_comp:.2f}ms.\n"
                f"  Payload Ratio: {breakdown.payload_ratio:.3f}x | Storage Ratio: {breakdown.storage_ratio:.3f}x\n"
                f"  Container file: {out_path}"
            )
            messagebox.showinfo(
                "Compression Complete",
                f"Compressed to {Path(out_path).name}\n"
                f"Payload Ratio: {breakdown.payload_ratio:.2f}x\n"
                f"Actual Storage Ratio: {breakdown.storage_ratio:.2f}x"
            )

    def _do_decompress(self):
        f = filedialog.askopenfilename(
            title="Select .clab File to Decompress",
            filetypes=[("Compression Laboratory Container", "*.clab")]
        )
        if not f:
            return

        try:
            with open(f, "rb") as fl:
                clab_bytes = fl.read()

            t0 = time.perf_counter()
            meta, decomp_bytes = decompress_container(clab_bytes, verify_checksum=True)
            t_decomp = (time.perf_counter() - t0) * 1000.0

            if meta.is_archive:
                out_dir = filedialog.askdirectory(title="Select Extraction Destination Directory")
                if out_dir:
                    extracted = unpack_directory(decomp_bytes, out_dir)
                    self.log(
                        f"Decompressed and verified archive '{Path(f).name}' in {t_decomp:.2f}ms!\n"
                        f"  Extracted {len(extracted)} files/folders to {out_dir}.\n"
                        f"  Integrity: CRC32 0x{meta.original_crc32:08X} MATCH CONFIRMED."
                    )
                    messagebox.showinfo("Success", f"Archive extracted successfully to:\n{out_dir}")
            else:
                suggested_name = meta.filename if meta.filename else "decompressed_file"
                out_file = filedialog.asksaveasfilename(
                    title="Save Decompressed File",
                    initialfile=suggested_name
                )
                if out_file:
                    with open(out_file, "wb") as fl:
                        fl.write(decomp_bytes)
                    self.log(
                        f"Decompressed '{Path(f).name}' -> '{Path(out_file).name}' in {t_decomp:.2f}ms.\n"
                        f"  Reconstructed size: {format_size(len(decomp_bytes))}.\n"
                        f"  Integrity: CRC32 0x{meta.original_crc32:08X} EXACT MATCH."
                    )
                    messagebox.showinfo(
                        "Decompression Verified",
                        f"File restored and verified!\nExact Match: {format_size(len(decomp_bytes))}"
                    )

        except Exception as e:
            self.log(f"ERROR: Decompression failed: {e}")
            messagebox.showerror("Decompression Error", str(e))

    def log(self, msg: str):
        self.log_text.insert("end", f"[{time.strftime('%H:%M:%S')}] {msg}\n")
        self.log_text.see("end")
        if self.log_callback:
            self.log_callback(msg)
