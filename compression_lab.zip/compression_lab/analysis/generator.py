"""
Unified Entropy-Controlled Data and File Generator.
Generates binary files of arbitrary sizes (from a few bytes to 100+ MB) with a
continuous, mathematically calibrated target entropy normalized between 0.0 and 1.0.

Mathematical Foundation:
- Entropy 0.0: Fully constant, completely predictable data (H = 0.0 bits/symbol).
- Entropy 1.0: Uniform random distribution over all 256 byte values (H = 8.0 bits/symbol).
- Intermediate [0.0..1.0]: Gibbs / Boltzmann distribution p(i) ~ exp(-beta * i)
  where beta is found via bisection search to match target Shannon entropy H = E * 8.0 bits.
- Large files are written in streaming chunks to keep memory usage minimal (O(chunk_size)).
"""

import math
from pathlib import Path
from typing import Optional, Tuple, Callable
import numpy as np


def compute_gibbs_probabilities(target_entropy_bits: float, alphabet_size: int = 256) -> np.ndarray:
    """
    Computes a 256-symbol probability distribution matching the target entropy.
    Uses bisection search on the concentration parameter beta in p(i) ~ exp(-beta * i).
    """
    max_h = math.log2(alphabet_size)  # 8.0 bits for 256 symbols
    target = max(0.0, min(target_entropy_bits, max_h))

    # Boundary cases
    if target >= max_h - 1e-5:
        return np.full(alphabet_size, 1.0 / alphabet_size, dtype=np.float64)
    if target <= 1e-5:
        probs = np.zeros(alphabet_size, dtype=np.float64)
        probs[0] = 1.0
        return probs

    ranks = np.arange(alphabet_size, dtype=np.float64)

    def entropy_at_beta(beta: float) -> float:
        # Numerically stable softmax with temperature
        scaled = -beta * ranks
        scaled -= np.max(scaled)
        exp_weights = np.exp(scaled)
        p = exp_weights / np.sum(exp_weights)
        # Shannon entropy H(P)
        h = 0.0
        for val in p:
            if val > 1e-15:
                h -= val * math.log2(val)
        return h

    # Bisection search: beta is in [0.0, 50.0]
    low = 0.0
    high = 50.0
    for _ in range(40):
        mid = (low + high) / 2.0
        h_mid = entropy_at_beta(mid)
        if h_mid < target:
            high = mid
        else:
            low = mid

    scaled = -low * ranks
    scaled -= np.max(scaled)
    weights = np.exp(scaled)
    return weights / np.sum(weights)


def calculate_empirical_entropy(freq_counts: np.ndarray, total_bytes: int) -> float:
    """Computes measured empirical Shannon entropy from frequency counts."""
    if total_bytes <= 0:
        return 0.0
    h = 0.0
    for count in freq_counts:
        if count > 0:
            p = count / total_bytes
            h -= p * math.log2(p)
    return h


def generate_entropy_bytes(
    size_bytes: int,
    target_normalized_entropy: float,
    seed: Optional[int] = None
) -> Tuple[bytes, float, float]:
    """
    Generates in-memory bytes with calibrated target entropy.
    Returns (data_bytes, target_bits, measured_bits).
    """
    target_normalized = max(0.0, min(1.0, float(target_normalized_entropy)))
    target_bits = target_normalized * 8.0

    if size_bytes <= 0:
        return b"", target_bits, 0.0

    # Fast path for zero entropy: constant zeros
    if target_normalized <= 1e-5:
        data = bytes(size_bytes)
        return data, target_bits, 0.0

    rng = np.random.default_rng(seed)
    symbols = np.arange(256, dtype=np.uint8)
    probs = compute_gibbs_probabilities(target_bits, alphabet_size=256)

    # Sample symbols
    sampled = rng.choice(symbols, size=size_bytes, p=probs)
    data = sampled.tobytes()

    # Measure exact empirical entropy
    counts = np.bincount(sampled, minlength=256)
    measured_bits = calculate_empirical_entropy(counts, size_bytes)

    return data, target_bits, measured_bits


def generate_entropy_file(
    filepath: str,
    size_bytes: int,
    target_normalized_entropy: float,
    seed: Optional[int] = None,
    chunk_size: int = 1048576,  # 1 MB streaming chunks
    progress_callback: Optional[Callable[[int, int], None]] = None
) -> Tuple[float, float, int]:
    """
    Streams generated data directly to disk in chunks to handle arbitrarily large files (e.g. 100 MB).
    Returns (target_bits, measured_bits, total_bytes_written).
    """
    target_normalized = max(0.0, min(1.0, float(target_normalized_entropy)))
    target_bits = target_normalized * 8.0

    dest_path = Path(filepath)
    dest_path.parent.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(seed)
    symbols = np.arange(256, dtype=np.uint8)
    probs = compute_gibbs_probabilities(target_bits, alphabet_size=256)

    total_counts = np.zeros(256, dtype=np.int64)
    bytes_written = 0

    with open(dest_path, "wb") as f:
        while bytes_written < size_bytes:
            current_chunk_size = min(chunk_size, size_bytes - bytes_written)

            if target_normalized <= 1e-5:
                # Constant zeros
                chunk_bytes = bytes(current_chunk_size)
                total_counts[0] += current_chunk_size
            elif target_normalized >= 0.99999:
                # Fast uniform random bytes
                chunk_array = rng.integers(0, 256, size=current_chunk_size, dtype=np.uint8)
                chunk_bytes = chunk_array.tobytes()
                counts = np.bincount(chunk_array, minlength=256)
                total_counts += counts
            else:
                chunk_array = rng.choice(symbols, size=current_chunk_size, p=probs)
                chunk_bytes = chunk_array.tobytes()
                counts = np.bincount(chunk_array, minlength=256)
                total_counts += counts

            f.write(chunk_bytes)
            bytes_written += current_chunk_size

            if progress_callback:
                progress_callback(bytes_written, size_bytes)

    measured_bits = calculate_empirical_entropy(total_counts, bytes_written)
    return target_bits, measured_bits, bytes_written
