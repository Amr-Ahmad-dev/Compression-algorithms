"""
Base classes and result structures for compression algorithms.
Provides clean dataclasses for algorithm configurations, execution traces,
and separated payload vs storage compression accounting.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Dict, Any, List, Optional


class AlgorithmId(IntEnum):
    """Unique identifiers for all supported algorithms."""
    HUFFMAN = 1
    ARITHMETIC_STATIC = 2
    ARITHMETIC_ADAPTIVE = 3
    SHANNON_FANO = 4
    LZW = 5
    RLE = 6
    DELTA_HUFFMAN = 7


@dataclass
class AlgorithmConfig:
    """Configurable parameters for compression algorithms."""
    algorithm_id: AlgorithmId
    block_size: int = 1         # 1 for byte-level; 2, 3, 4 for multi-byte blocks
    precision_bits: int = 32    # Integer precision for arithmetic coding
    adaptive: bool = False      # Static vs Adaptive probability modeling
    max_dict_size: int = 4096   # Maximum dictionary entries for LZW
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class StepTrace:
    """Educational step record for visualizing encoding/decoding."""
    step_num: int
    description: str
    symbol: Optional[Any] = None
    codeword: Optional[str] = None
    state: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CompressionResult:
    """Output from an algorithm compression pass."""
    compressed_bytes: bytes      # Raw encoded payload bitstream
    model_metadata: bytes        # Serialized tree, model, or codebook
    original_size: int           # Original uncompressed size in bytes
    compressed_payload_size: int # Payload byte length
    total_model_size: int        # Model metadata byte length
    block_size: int              # Block size used
    algorithm_id: AlgorithmId
    traces: List[StepTrace] = field(default_factory=list)


@dataclass
class DecompressionResult:
    """Output from an algorithm decompression pass."""
    decompressed_bytes: bytes
    original_size: int
    traces: List[StepTrace] = field(default_factory=list)


@dataclass
class ContainerBreakdown:
    """
    Detailed size accounting distinguishing payload efficiency from storage overhead.
    """
    original_size: int
    payload_size: int
    model_size: int
    header_size: int
    total_container_size: int
    # Payload Compression (Algorithm efficiency alone)
    payload_ratio: float
    payload_savings_pct: float
    # Actual Storage Compression (Real disk space including all container overhead)
    storage_ratio: float
    storage_savings_pct: float
    # Overhead analysis
    total_overhead_size: int
    overhead_pct_of_container: float
    overhead_eliminates_savings: bool


def compute_container_breakdown(
    original_size: int,
    payload_size: int,
    model_size: int,
    header_size: int
) -> ContainerBreakdown:
    """
    Calculates separate payload and storage compression metrics.
    Accurately detects when metadata overhead negates payload compression.
    """
    total_size = payload_size + model_size + header_size
    total_overhead = model_size + header_size

    # 1. Payload compression metrics
    if payload_size > 0:
        payload_ratio = original_size / payload_size
    else:
        payload_ratio = 1.0 if original_size == 0 else 0.0

    if original_size > 0:
        payload_savings_pct = ((original_size - payload_size) / original_size) * 100.0
    else:
        payload_savings_pct = 0.0

    # 2. Actual storage compression metrics
    if total_size > 0:
        storage_ratio = original_size / total_size
    else:
        storage_ratio = 1.0 if original_size == 0 else 0.0

    if original_size > 0:
        storage_savings_pct = ((original_size - total_size) / original_size) * 100.0
    else:
        storage_savings_pct = 0.0

    overhead_pct = (total_overhead / total_size * 100.0) if total_size > 0 else 0.0
    eliminates_savings = (payload_savings_pct > 0.0) and (storage_savings_pct <= 0.0)

    return ContainerBreakdown(
        original_size=original_size,
        payload_size=payload_size,
        model_size=model_size,
        header_size=header_size,
        total_container_size=total_size,
        payload_ratio=round(payload_ratio, 3),
        payload_savings_pct=round(payload_savings_pct, 2),
        storage_ratio=round(storage_ratio, 3),
        storage_savings_pct=round(storage_savings_pct, 2),
        total_overhead_size=total_overhead,
        overhead_pct_of_container=round(overhead_pct, 2),
        overhead_eliminates_savings=eliminates_savings
    )


class CompressionAlgorithm(ABC):
    """Abstract base class for all compression algorithms."""

    @property
    @abstractmethod
    def algorithm_id(self) -> AlgorithmId:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def compress(
        self,
        data: bytes,
        config: Optional[AlgorithmConfig] = None,
        record_trace: bool = False,
        max_traces: int = 100
    ) -> CompressionResult:
        pass

    @abstractmethod
    def decompress(
        self,
        compressed_bytes: bytes,
        model_metadata: bytes,
        original_size: int,
        config: Optional[AlgorithmConfig] = None,
        record_trace: bool = False,
        max_traces: int = 100
    ) -> DecompressionResult:
        pass
