"""
Benchmarking and Tournament System for the Compression Laboratory.
Executes fair side-by-side compression competitions with exact binary container measurements,
separate payload vs storage metrics, integrity verification, ranking metrics, and CSV/JSON export.
"""

import time
import json
import csv
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

from algorithms.base import AlgorithmId, AlgorithmConfig, ContainerBreakdown, compute_container_breakdown
from algorithms import get_algorithm
from core.container import build_container, decompress_container
from core.statistics import analyze_bytes


@dataclass
class TournamentEntry:
    algorithm_id: AlgorithmId
    name: str
    config: AlgorithmConfig


@dataclass
class BenchmarkRecord:
    dataset_name: str
    algorithm_name: str
    algorithm_id: int
    block_size: int
    original_size: int
    # Sizing breakdown
    payload_size: int
    model_metadata_size: int
    header_overhead_size: int
    total_container_size: int
    # 1. Payload compression
    payload_ratio: float
    payload_savings_pct: float
    # 2. Actual storage compression
    storage_ratio: float
    storage_savings_pct: float
    overhead_eliminates_savings: bool
    # Timing & Verification
    compression_time_ms: float
    decompression_time_ms: float
    source_entropy: float
    theoretical_min_bytes: float
    integrity_verified: bool
    # Rankings
    rank_storage: int = 0
    rank_payload: int = 0
    rank_speed: int = 0
    performance_insight: str = ""


class TournamentRunner:
    """Executes compression tournaments across algorithms and datasets."""

    def __init__(self):
        self.records: List[BenchmarkRecord] = []

    def run_single_competition(
        self,
        data: bytes,
        dataset_name: str,
        competitors: List[TournamentEntry]
    ) -> List[BenchmarkRecord]:
        """
        Runs all competitors against the same raw byte input.
        Verifies reconstruction for every entry.
        """
        stats = analyze_bytes(data)
        entropy = stats.shannon_entropy
        orig_size = len(data)
        theo_min = stats.theoretical_min_size_bytes

        batch_records: List[BenchmarkRecord] = []

        for comp in competitors:
            algo = get_algorithm(comp.algorithm_id)

            # 1. Compression Time
            t0 = time.perf_counter()
            comp_res = algo.compress(data, comp.config)
            t_comp = (time.perf_counter() - t0) * 1000.0

            # 2. Package into full self-contained container
            clab_bytes = build_container(comp_res, data, dataset_name, is_archive=False)
            total_size = len(clab_bytes)

            # 3. Decompression Time & Integrity Verification
            t0 = time.perf_counter()
            meta, decomp_data = decompress_container(clab_bytes, verify_checksum=True)
            t_decomp = (time.perf_counter() - t0) * 1000.0

            verified = (decomp_data == data)
            if not verified:
                raise RuntimeError(
                    f"FATAL: Algorithm {comp.name} failed roundtrip integrity verification on dataset {dataset_name}!"
                )

            # Sizing breakdown
            fname_len = len(dataset_name.encode("utf-8"))
            header_overhead = 23 + fname_len + 4 + 8
            model_size = comp_res.total_model_size
            payload_size = comp_res.compressed_payload_size

            breakdown = compute_container_breakdown(
                original_size=orig_size,
                payload_size=payload_size,
                model_size=model_size,
                header_size=header_overhead
            )

            # Generate insight note
            if orig_size == 0:
                insight = "Empty file test."
            elif breakdown.overhead_eliminates_savings:
                insight = (
                    f"Payload compressed ({breakdown.payload_savings_pct:+.1f}%), but model+header "
                    f"overhead ({breakdown.total_overhead_size} B) caused net storage expansion ({breakdown.storage_savings_pct:+.1f}%)."
                )
            elif breakdown.storage_savings_pct > 0:
                overhead_ratio = (breakdown.total_overhead_size / total_size) * 100
                insight = f"Net storage saved {breakdown.storage_savings_pct:.1f}% (Overhead was {overhead_ratio:.1f}% of container)."
            else:
                insight = f"No compression achieved on this data pattern (Storage change {breakdown.storage_savings_pct:+.1f}%)."

            record = BenchmarkRecord(
                dataset_name=dataset_name,
                algorithm_name=comp.name,
                algorithm_id=int(comp.algorithm_id),
                block_size=comp.config.block_size,
                original_size=orig_size,
                payload_size=payload_size,
                model_metadata_size=model_size,
                header_overhead_size=header_overhead,
                total_container_size=total_size,
                payload_ratio=breakdown.payload_ratio,
                payload_savings_pct=breakdown.payload_savings_pct,
                storage_ratio=breakdown.storage_ratio,
                storage_savings_pct=breakdown.storage_savings_pct,
                overhead_eliminates_savings=breakdown.overhead_eliminates_savings,
                compression_time_ms=round(t_comp, 3),
                decompression_time_ms=round(t_decomp, 3),
                source_entropy=round(entropy, 4),
                theoretical_min_bytes=round(theo_min, 1),
                integrity_verified=verified,
                performance_insight=insight
            )
            batch_records.append(record)

        # Compute rankings
        # 1. Storage ranking (smaller total container size is best)
        sorted_by_storage = sorted(batch_records, key=lambda r: r.total_container_size)
        for rank, r in enumerate(sorted_by_storage, start=1):
            r.rank_storage = rank

        # 2. Payload ranking (smaller payload is best)
        sorted_by_payload = sorted(batch_records, key=lambda r: r.payload_size)
        for rank, r in enumerate(sorted_by_payload, start=1):
            r.rank_payload = rank

        # 3. Speed ranking (fastest total time is best)
        sorted_by_speed = sorted(batch_records, key=lambda r: (r.compression_time_ms + r.decompression_time_ms))
        for rank, r in enumerate(sorted_by_speed, start=1):
            r.rank_speed = rank

        self.records.extend(batch_records)
        return batch_records

    def export_to_csv(self, filepath: str) -> None:
        """Exports all recorded benchmark results to CSV."""
        if not self.records:
            return
        fieldnames = list(asdict(self.records[0]).keys())
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in self.records:
                writer.writerow(asdict(r))

    def export_to_json(self, filepath: str) -> None:
        """Exports all recorded benchmark results to JSON."""
        data = [asdict(r) for r in self.records]
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
