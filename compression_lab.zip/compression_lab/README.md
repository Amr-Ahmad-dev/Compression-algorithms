# 🔬 Antigravity File Compression Laboratory

A simplified, educational, functional, and visually appealing **File Compression Laboratory** built from scratch in Python.

This laboratory provides an interactive research environment to study, implement, visualize, compare, and benchmark lossless data compression algorithms while understanding the fundamental mathematical relationships between probability distributions, Shannon entropy, autocorrelation, and compressibility.

---

## ⚡ Core Principles
1. **Zero External Compression Libraries**: Every algorithm (Huffman, Arithmetic Coding, Shannon-Fano, LZW, RLE, Delta Preprocessing) is implemented from scratch.
2. **Strict Invariant**: For every file and algorithm, \(\text{decompress}(\text{compress}(\text{data})) \equiv \text{data}\).
3. **Dual Metric Size Accounting**: Distinguishes algorithm efficiency (raw payload size) from actual storage efficiency (total container size including headers, codebooks, and metadata).
4. **Unified Entropy-Controlled Generator**: Produces binary files of arbitrary sizes (up to 100+ MB) with a continuous target entropy \(E \in [0.0, 1.0]\) using streaming chunks.

---

## 📐 Mathematical Foundations

### 1. Shannon Entropy
The theoretical zero-order empirical entropy \(H(X)\) represents the absolute minimum average bits required per byte without loss:
\[
H(X) = -\sum_{x \in \mathcal{X}} p(x) \log_2 p(x) \quad \text{[bits/symbol]}
\]
- For a byte alphabet (\(|\mathcal{X}| = 256\)), the maximum possible entropy is \(\log_2(256) = 8.0\) bits/symbol (uniform distribution).
- **Shannon Source Coding Lower Bound**:
  \[
  \text{Min Lossless Size (Bytes)} = \frac{N \times H(X)}{8}
  \]

### 2. Dual Compression Metrics
- **Payload Compression (Core Algorithm Performance)**:
  \[
  \text{Payload Ratio} = \frac{\text{Original Size}}{\text{Payload Size}}, \quad \text{Payload Savings} = \frac{\text{Original Size} - \text{Payload Size}}{\text{Original Size}} \times 100\%
  \]
- **Actual Storage Compression (Real Container on Disk)**:
  \[
  \text{Storage Ratio} = \frac{\text{Original Size}}{\text{Total Container Size}}, \quad \text{Storage Savings} = \frac{\text{Original Size} - \text{Total Container Size}}{\text{Original Size}} \times 100\%
  \]
  *Visually highlights when an algorithm compresses the payload well, but model or header overhead eliminates real storage savings (especially on small files).*

---

## 🛠 Implemented Algorithms (From Scratch)

### 1. Huffman Encoding (`algorithms/huffman.py`)
- **Deterministic Priority Queue**: Implements min-heap tree construction with deterministic tie-breaking.
- **Configurable Symbol Blocks**: Supports single-byte (\(K=1\)) and multi-byte blocks (\(K=2, 3, 4\)) with exact handling of incomplete final blocks.
- **Compact Tree Serialization**: Pre-order bitstream representation.

### 2. Integer Arithmetic Coding (`algorithms/arithmetic.py`)
- **Numerically Safe 32-bit Integer Arithmetic**: Implements Witten-Neal-Cleary (WNC) integer arithmetic coding.
- **Underflow Handling (E3 Mapping)**: Tracks pending bits when intervals straddle the midpoint.
- **Static & Adaptive Models**: Static precomputes source frequencies; Adaptive updates probabilities online with dynamic rescaling.

### 3. Shannon-Fano Encoding (`algorithms/shannon_fano.py`)
- **Recursive Binary Partitioning**: Divides frequency-sorted subsets minimizing absolute frequency divergence \(|S_1 - S_2|\).
- **Deterministic Tie-Breaking**: Secondary sorting on byte values ensures identical encoder/decoder trees.

### 4. Run-Length Encoding (RLE) (`algorithms/rle.py`)
- **Binary-Safe PackBits**: Control byte \(n \in [0, 127]\) indicates literal run; \(n \in [129, 255]\) indicates repeated run.

### 5. Lempel-Ziv-Welch (LZW) (`algorithms/lzw.py`)
- **Dictionary Compression**: Online dictionary building from 256 byte literals up to 65,535 entries.
- **KwKwK Solution**: Solves the classic decompressor edge case where a code is not yet in the dictionary.

### 6. Delta Preprocessing (`algorithms/delta.py`)
- **Reversible Byte Differencing**: Computes \(y[0] = x[0], y[i] = (x[i] - x[i-1]) \pmod{256}\).

---

## 🎲 Unified Entropy-Controlled File Generator (`analysis/generator.py`)

A single mathematically grounded Boltzmann model generates data from completely predictable to maximum randomness:
- **Entropy 0.0**: Constant, predictable data (\(H = 0.0\) bits/byte).
- **Entropy 1.0**: Uniform random bytes across all 256 symbols (\(H = 8.0\) bits/byte).
- **Intermediate \(E \in (0, 1)\)**: Uses bisection search on Gibbs concentration parameter \(\beta\) in \(p(i) \propto \exp(-\beta \cdot i)\) to match target \(H = E \times 8.0\) bits.
- **Streaming Chunks**: Writes 1 MB chunks directly to disk with \(O(1)\) RAM usage, supporting files up to 100+ MB.
- **Empirical Measurement**: Displays both requested target entropy and measured empirical entropy of the generated file.

---

## 📦 Container Binary Specification (`.clab`)

Every compressed file is completely self-contained:
- Magic: `CLAB` (4 bytes ASCII)
- Version: uint8 (`1`)
- Algorithm ID: uint8
- Flags: uint16 BE (Bit 0: IsArchive, Bit 1: DeltaApplied)
- Block Size: uint8
- Original Size: uint64 BE
- CRC32: uint32 BE (Integrity checksum of uncompressed bytes)
- Filename Length: uint16 BE + Filename UTF-8 bytes
- Model Metadata Length: uint32 BE + Model Metadata bytes
- Payload Length: uint64 BE + Compressed Payload bitstream

---

## 🚀 Execution Instructions

### Run the Graphical Desktop Application (GUI)
```powershell
python main.py
```

### Run Tournament Demo (CLI)
```powershell
python main.py --cli
```

### Generate a Calibrated Binary File
```powershell
# Generate a 10 MB file with normalized target entropy 0.40 (3.2 bits/byte)
python main.py --generate-file dataset_10mb.bin --size 10485760 --entropy 0.40 --seed 42
```

### Run Tournament on Any File
```powershell
python main.py --benchmark-file dataset_10mb.bin
```

### Inspect File Statistics
```powershell
python main.py --file dataset_10mb.bin
```

### Run Full Test Suite
```powershell
pytest tests -v
```
