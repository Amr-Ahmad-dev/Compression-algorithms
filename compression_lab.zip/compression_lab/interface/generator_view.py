"""
Unified Entropy-Controlled File Generator View.
Enables creating real binary files of arbitrary sizes (from KB up to 100+ MB)
with normalized target entropy [0.0..1.0] and streaming chunk-based writing.
"""

from pathlib import Path
from tkinter import filedialog, messagebox
import customtkinter as ctk
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

from algorithms import get_algorithm
from algorithms.base import AlgorithmId, AlgorithmConfig
from analysis.generator import (
    generate_entropy_file,
    generate_entropy_bytes
)
from core.statistics import analyze_file, analyze_bytes
from visualization.charts import create_entropy_vs_ratio_figure


class GeneratorView(ctk.CTkFrame):
    def __init__(self, master, get_shared_state, set_shared_state, log_callback, **kwargs):
        super().__init__(master, **kwargs)
        self.get_shared_state = get_shared_state
        self.set_shared_state = set_shared_state
        self.log_callback = log_callback
        self.canvas = None
        self.current_fig = None

        self._build_ui()

    def _build_ui(self):
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure(1, weight=1)

        # 1. Generator Parameters Card (Left Side)
        gen_card = ctk.CTkFrame(self, corner_radius=10)
        gen_card.grid(row=0, column=0, rowspan=2, padx=(15, 6), pady=10, sticky="nsew")

        ctk.CTkLabel(
            gen_card,
            text="Unified Entropy-Controlled Generator",
            font=ctk.CTkFont(size=14, weight="bold")
        ).pack(anchor="w", padx=15, pady=(12, 4))

        ctk.CTkLabel(
            gen_card,
            text="A single mathematically calibrated Boltzmann model produces data from completely predictable (Entropy 0.0) to maximum uncertainty (Entropy 1.0 = 8.0 bits).",
            wraplength=340,
            justify="left",
            font=ctk.CTkFont(size=11),
            text_color="#94A3B8"
        ).pack(anchor="w", padx=15, pady=(0, 10))

        # Size Selection with Quick Presets
        ctk.CTkLabel(gen_card, text="File Size:", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=15, pady=(4, 2))
        preset_frame = ctk.CTkFrame(gen_card, fg_color="transparent")
        preset_frame.pack(fill="x", padx=15, pady=2)
        for label, val in [("100 KB", 102400), ("1 MB", 1048576), ("10 MB", 10485760), ("50 MB", 52428800)]:
            ctk.CTkButton(
                preset_frame,
                text=label,
                width=65,
                height=26,
                fg_color=("#CBD5E1", "#334155"),
                text_color=("#0F172A", "#F8FAFC"),
                command=lambda v=val: self._set_size_preset(v)
            ).pack(side="left", padx=3)

        size_custom_frame = ctk.CTkFrame(gen_card, fg_color="transparent")
        size_custom_frame.pack(fill="x", padx=15, pady=(4, 8))
        ctk.CTkLabel(size_custom_frame, text="Exact Bytes:").pack(side="left")
        self.size_entry = ctk.CTkEntry(size_custom_frame, width=150)
        self.size_entry.insert(0, "1048576")
        self.size_entry.pack(side="right")

        # Normalized Target Entropy Slider [0.0..1.0]
        ctk.CTkLabel(gen_card, text="Target Normalized Entropy [0.0 to 1.0]:", font=ctk.CTkFont(weight="bold")).pack(
            anchor="w", padx=15, pady=(8, 2)
        )
        self.slider_entropy = ctk.CTkSlider(gen_card, from_=0.0, to=1.0, number_of_steps=100, command=self._on_slider_moved)
        self.slider_entropy.set(0.50)
        self.slider_entropy.pack(fill="x", padx=15, pady=2)

        self.lbl_entropy_value = ctk.CTkLabel(
            gen_card,
            text="Normalized: 0.50 | Target H(X): 4.00 bits/byte",
            font=ctk.CTkFont(weight="bold"),
            text_color="#38BDF8"
        )
        self.lbl_entropy_value.pack(anchor="w", padx=15, pady=(0, 6))

        # Random Seed
        seed_frame = ctk.CTkFrame(gen_card, fg_color="transparent")
        seed_frame.pack(fill="x", padx=15, pady=(4, 8))
        ctk.CTkLabel(seed_frame, text="Random Seed (Optional):").pack(side="left")
        self.seed_entry = ctk.CTkEntry(seed_frame, width=120, placeholder_text="e.g. 42")
        self.seed_entry.insert(0, "42")
        self.seed_entry.pack(side="right")

        # Action Buttons
        btn_box = ctk.CTkFrame(gen_card, fg_color="transparent")
        btn_box.pack(fill="x", padx=15, pady=10)

        ctk.CTkButton(
            btn_box,
            text="Generate & Save Real File (.bin)",
            fg_color="#3A86FF",
            hover_color="#2563EB",
            font=ctk.CTkFont(weight="bold"),
            command=self._generate_and_save_file
        ).pack(fill="x", pady=4)

        ctk.CTkButton(
            btn_box,
            text="Generate & Set as Active File",
            fg_color="#10B981",
            hover_color="#059669",
            font=ctk.CTkFont(weight="bold"),
            command=self._generate_in_memory_active
        ).pack(fill="x", pady=4)

        # Output / Progress Card
        self.status_box = ctk.CTkFrame(gen_card, corner_radius=8, fg_color=("#E2E8F0", "#1E293B"))
        self.status_box.pack(fill="x", padx=15, pady=10)

        self.lbl_gen_status = ctk.CTkLabel(
            self.status_box,
            text="Status: Ready to generate.",
            justify="left",
            font=ctk.CTkFont(size=11),
            wraplength=320
        )
        self.lbl_gen_status.pack(anchor="w", padx=10, pady=8)

        # 2. Automated Sweep Experiment Card (Right Top)
        exp_card = ctk.CTkFrame(self, corner_radius=10)
        exp_card.grid(row=0, column=1, padx=(6, 15), pady=10, sticky="ew")

        ctk.CTkLabel(
            exp_card,
            text="Automated Multi-Algorithm Entropy Sweep",
            font=ctk.CTkFont(size=13, weight="bold")
        ).pack(anchor="w", padx=15, pady=(10, 4))

        ctk.CTkLabel(
            exp_card,
            text="Sweeps normalized entropy from 0.1 to 0.95 across multiple algorithms, measuring empirical entropy vs actual storage compression ratio.",
            wraplength=420,
            justify="left",
            font=ctk.CTkFont(size=11),
            text_color="#94A3B8"
        ).pack(anchor="w", padx=15, pady=(0, 8))

        ctk.CTkButton(
            exp_card,
            text="Run Automated Entropy Sweep (6 Points)",
            fg_color="#F72585",
            hover_color="#B5179E",
            font=ctk.CTkFont(weight="bold"),
            command=self._run_entropy_sweep
        ).pack(anchor="w", padx=15, pady=(0, 10))

        # 3. Chart Container (Right Bottom)
        self.chart_frame = ctk.CTkFrame(self, corner_radius=10)
        self.chart_frame.grid(row=1, column=1, padx=(6, 15), pady=(0, 10), sticky="nsew")

    def _set_size_preset(self, val: int):
        self.size_entry.delete(0, "end")
        self.size_entry.insert(0, str(val))

    def _on_slider_moved(self, val: float):
        target_bits = val * 8.0
        self.lbl_entropy_value.configure(text=f"Normalized: {val:.2f} | Target H(X): {target_bits:.2f} bits/byte")

    def _get_size_and_seed(self):
        try:
            size_val = int(self.size_entry.get().strip().replace(",", ""))
            if size_val <= 0:
                raise ValueError()
        except ValueError:
            messagebox.showerror("Invalid Size", "Please enter a valid positive integer for size in bytes.")
            return None, None

        seed_text = self.seed_entry.get().strip()
        seed = int(seed_text) if seed_text.isdigit() else None
        return size_val, seed

    def _generate_and_save_file(self):
        size_val, seed = self._get_size_and_seed()
        if size_val is None:
            return

        norm_entropy = float(self.slider_entropy.get())
        target_bits = norm_entropy * 8.0

        save_path = filedialog.asksaveasfilename(
            title="Save Generated Binary File",
            initialfile=f"generated_entropy_{norm_entropy:.2f}_{size_val}B.bin",
            defaultextension=".bin"
        )
        if not save_path:
            return

        self.lbl_gen_status.configure(text="Generating file in streaming chunks...")
        self.update_idletasks()

        target_h, meas_h, written = generate_entropy_file(
            filepath=save_path,
            size_bytes=size_val,
            target_normalized_entropy=norm_entropy,
            seed=seed
        )

        status_msg = (
            f"✓ File successfully created!\n"
            f"Path: {Path(save_path).name}\n"
            f"Size: {written:,} Bytes\n"
            f"Requested: {norm_entropy:.2f} ({target_h:.2f} bits) | Measured: {meas_h:.4f} bits/byte"
        )
        self.lbl_gen_status.configure(text=status_msg)

        # Prompt to set as active
        if messagebox.askyesno("File Generated", f"{status_msg}\n\nSet this file as active in the Laboratory?"):
            self._load_file_as_active(save_path)

    def _generate_in_memory_active(self):
        size_val, seed = self._get_size_and_seed()
        if size_val is None:
            return

        # Cap in-memory active data at 5 MB to keep UI responsive
        if size_val > 5242880:
            if not messagebox.askyesno(
                "Large In-Memory Data",
                "The requested size is large (> 5 MB). It is recommended to use 'Generate & Save Real File' to stream to disk. Proceed in memory anyway?"
            ):
                return

        norm_entropy = float(self.slider_entropy.get())
        data, target_h, meas_h = generate_entropy_bytes(size_val, norm_entropy, seed=seed)

        name = f"generated_H{meas_h:.2f}_{size_val}B.bin"
        stats = analyze_bytes(data, source_name=name)

        self.set_shared_state("active_data", data)
        self.set_shared_state("active_name", name)
        self.set_shared_state("active_path", "")
        self.set_shared_state("is_archive", False)
        self.set_shared_state("active_stats", stats)

        status_msg = (
            f"✓ Loaded {len(data):,} bytes into active memory!\n"
            f"Requested: {target_h:.2f} bits | Measured: {meas_h:.4f} bits/symbol."
        )
        self.lbl_gen_status.configure(text=status_msg)
        messagebox.showinfo("Active File Updated", status_msg)

    def _load_file_as_active(self, filepath: str):
        p = Path(filepath)
        stats = analyze_file(str(p.resolve()))

        with open(p, "rb") as fl:
            raw_bytes = fl.read()

        self.set_shared_state("active_data", raw_bytes)
        self.set_shared_state("active_name", p.name)
        self.set_shared_state("active_path", str(p.resolve()))
        self.set_shared_state("is_archive", False)
        self.set_shared_state("active_stats", stats)

    def _run_entropy_sweep(self):
        target_entropies = [0.15, 0.35, 0.50, 0.65, 0.80, 0.95]
        size = 16384  # 16 KB per point

        algos_to_test = [
            ("Huffman", AlgorithmId.HUFFMAN),
            ("Arithmetic (Static)", AlgorithmId.ARITHMETIC_STATIC),
            ("Shannon-Fano", AlgorithmId.SHANNON_FANO),
            ("LZW", AlgorithmId.LZW)
        ]

        actual_entropies = []
        ratios_by_algo = {name: [] for name, _ in algos_to_test}

        for norm_e in target_entropies:
            data, _, meas_h = generate_entropy_bytes(size, norm_e, seed=100)
            actual_entropies.append(meas_h)

            for name, algo_id in algos_to_test:
                algo = get_algorithm(algo_id)
                cfg = AlgorithmConfig(algorithm_id=algo_id, block_size=1)
                res = algo.compress(data, cfg)
                total_size = len(res.compressed_bytes) + len(res.model_metadata) + 35
                ratio = len(data) / total_size if total_size > 0 else 0.0
                ratios_by_algo[name].append(ratio)

        # Plot
        if self.current_fig:
            plt.close(self.current_fig)
        if self.canvas:
            self.canvas.get_tk_widget().destroy()

        fig = create_entropy_vs_ratio_figure(actual_entropies, ratios_by_algo, dark_mode=True)
        self.current_fig = fig
        self.canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)
